package com.usu.rougelike.game.gameengine;

import java.util.ArrayList;

public class Layer {
    public boolean isStatic = false;
    public ArrayList<GameObject> gameObjects = new ArrayList<>();
}
