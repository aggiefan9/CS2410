package com.usu.rougelike.game.gameengine;

public class Location {
    public float x;
    public float y;

    public Location(float x, float y) {
        this.x = x;
        this.y = y;
    }
}
