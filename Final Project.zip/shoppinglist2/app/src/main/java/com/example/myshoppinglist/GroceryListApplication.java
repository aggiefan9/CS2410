package com.example.myshoppinglist;

import android.app.Application;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class GroceryListApplication extends Application {
}
